import pandas as pd
import numpy as np
import xgboost as xgb
import joblib

#from inference import MODEL_PATH, PATH_DATA
from data_preparation import data_prep


MODEL_PATH = "model_1.pkl"
PATH_DATA = "data"
params = {
    'eta': 0.1,
    'max_depth': 3,
    'subsample': 0.8,
    'colsample_bytree': 0.8,

    'gamma': 0,
    'lambda': 0,
    'alpha': 0,
    'min_child_weight': 0,

    'eval_metric': 'auc',
    'objective': 'binary:logistic',
    'booster': 'gbtree',
    'njobs': -1,
    'tree_method': 'approx'
}


def fit(num_trees, train, target):
    params['learning_rate'] = params['eta']
    clf = xgb.train(params, xgb.DMatrix(train.values, target, feature_names=list(train.columns)),
                    num_boost_round=num_trees, maximize=True)
    return clf


data_train, data_test, target = data_prep(PATH_DATA)

clf = fit(69, data_train, target)
joblib.dump(clf, MODEL_PATH)
